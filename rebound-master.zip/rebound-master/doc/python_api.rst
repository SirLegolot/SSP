API documentation (Python)
==========================

.. automodule:: rebound
   :members:
   :special-members: __init__

